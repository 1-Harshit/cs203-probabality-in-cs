# CS203B-Mathematics in Computer Science

Assignment 2 submission of the semester 2021-22-II semester of CS203B at IIT Kanpur.

## Dependecy:

- Python version: 3.10

```
pip install matplotlib numpy
```

## How to run the code

```sh
python -u 200433_Q3.py
# you'll be promted to enter the input N
# then two images will be displayed one by one
```

## Author

- Name: Harshit Raj
- Email: harshitr20@iitk.ac.in
- Roll: 200433
- Date: 22 April 2022
